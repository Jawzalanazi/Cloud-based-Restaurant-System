
class DrinkVendingMachine {
    Stack<Item> juiceStack;
    Stack<Item> colaStack;
    Stack<Item> waterStack;

    public DrinkVendingMachine() {
        juiceStack = new Stack<>();
        colaStack = new Stack<>();
        waterStack = new Stack<>();
    }
}